﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class saveWiz
{
    public int[] SkillLevel;
    public bool[] canGetExp;
    public double[] exp;
}
