﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class keyList : MonoBehaviour
{
    public static string resetSaveKey = "saveR";
    public static string permanentSaveKey = "save";
    public static string War_saveKey = "saveWar";
    public static string Wiz_saveKey = "saveWiz";
    public static string Ang_saveKey = "saveAng";
}
