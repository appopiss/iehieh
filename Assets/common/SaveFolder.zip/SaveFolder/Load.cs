﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

public class Load : BASE, IPointerDownHandler
{
    public Button saveButton;
    string saveTitle, saveContent;
    string gameTitle = "IncrementalEpicHero";
    string sceneName = "main";
    bool isOver;
    public static bool isLoaded;
    AES aes = new AES();

    string[] saveStrArray = new string[5];
    string[] jsonArray = new string[5];

    private void Awake()
    {
        StartBASE();
    }

    void Start()
    {
        saveButton.onClick.AddListener(() => StartCoroutine(saveText()));
#if UNITY_EDITOR
#elif UNITY_WEBGL
        


        Application.ExternalEval(
            @"
document.addEventListener('click', function() {

    var fileuploader = document.getElementById('fileuploader');
    if (!fileuploader) {
        fileuploader = document.createElement('input');
        fileuploader.setAttribute('style','display:none;');
        fileuploader.setAttribute('type', 'file');
        fileuploader.setAttribute('id', 'fileuploader');
//        fileuploader.setAttribute('class', 'focused');
        document.getElementsByTagName('body')[0].appendChild(fileuploader);

        fileuploader.onchange = function(e) {
        var files = e.target.files;
            for (var i = 0, f; f = files[i]; i++) {
                //window.alert(URL.createObjectURL(f));

				//var reader = new FileReader();
				//reader.readAsText(f);

                SendMessage('" + gameObject.name + @"', 'FileDialogResult', URL.createObjectURL(f));
            }
        };
    }else{
	    if (fileuploader.getAttribute('class') == 'focused') {
	        fileuploader.setAttribute('class', '');
	        fileuploader.click();

	    }
	}
});
            ");
#endif
    }


    //Incentivized Ads 初回Bonusから呼ぶ
    public IEnumerator saveText()
    {
        saveTitle = gameTitle + "_" + DateTime.Now.ToString();

        saveStrArray[0] = PlayerPrefs.GetString(keyList.resetSaveKey);
        saveStrArray[1] = PlayerPrefs.GetString(keyList.permanentSaveKey);
        saveStrArray[2] = PlayerPrefs.GetString(keyList.Wiz_saveKey);
        saveStrArray[3] = PlayerPrefs.GetString(keyList.War_saveKey);
        saveStrArray[4] = PlayerPrefs.GetString(keyList.Ang_saveKey);
        //暗号化
        for (int i = 0; i < saveStrArray.Length; i++)
        {
            jsonArray[i] = null;
            jsonArray[i] = Convert.ToBase64String(aes.encrypt(System.Text.Encoding.UTF8.GetBytes(saveStrArray[i])));
            yield return jsonArray[i];
        }
        //結合
        saveContent = null;
        saveContent = string.Join("#", jsonArray);
        yield return saveContent;

#if UNITY_EDITOR
        //EditorのAssets/SaveData/にセーブ
        FileInfo file = new FileInfo(Application.dataPath + "/SaveData/" + gameTitle + "_OnEditor.txt");
        file.Directory.Create();
        File.WriteAllText(file.FullName, saveContent);

#elif UNITY_WEBGL
        Application.ExternalEval(
                    @"
		const a = document.createElement('a');
		a.href = URL.createObjectURL(new Blob(['"+ saveContent + @"'], {type: 'text/plain'}));
		a.download = '" + saveTitle + @"';

		a.style.display = 'none';
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		");
#endif
    }

    public void OnPointerDown(PointerEventData eventData)
    {
#if UNITY_EDITOR
        LoadOnEditor();
#elif UNITY_WEBGL
        Application.ExternalEval(
            @"
var fileuploader = document.getElementById('fileuploader');
if (!fileuploader) {
        fileuploader = document.createElement('input');
        fileuploader.setAttribute('style','display:none;');
        fileuploader.setAttribute('type', 'file');
        fileuploader.setAttribute('id', 'fileuploader');
		fileuploader.setAttribute('class', 'focused');
        document.getElementsByTagName('body')[0].appendChild(fileuploader);

        fileuploader.onchange = function(e) {
        var files = e.target.files;
            for (var i = 0, f; f = files[i]; i++) {
                //window.alert(URL.createObjectURL(f));

				//var reader = new FileReader();
				//reader.readAsText(f);

                SendMessage('" + gameObject.name + @"', 'FileDialogResult', URL.createObjectURL(f));
            }
        };
    }
if (fileuploader) {
    fileuploader.setAttribute('class', 'focused');
}
            ");
#endif
    }


    public void FileDialogResult(string fileUrl)
    {
        StartCoroutine(ReadTxt(fileUrl));
    }

    IEnumerator ReadTxt(string url)
    {
        //コルーチンを止める．
        foreach (ACHIEVEMENT achieve in main.quests)
        {
            if (achieve.QuestCor != null)
                StopCoroutine(achieve.QuestCor);
        }

        var www = new WWW(url);
        yield return www;
        jsonArray = www.text.Split('#');
        //復号化

        for (int i = 0; i < jsonArray.Length; i++)
        {
            saveStrArray[i] = null;
            saveStrArray[i] = System.Text.Encoding.UTF8.GetString(aes.dencrypt(Convert.FromBase64String(jsonArray[i])));
            yield return saveStrArray[i];
        }
        SaveR SRdata = JsonUtility.FromJson<SaveR>(saveStrArray[0]);
        Save Sdata = JsonUtility.FromJson<Save>(saveStrArray[1]);
        saveWiz WizData = JsonUtility.FromJson<saveWiz>(saveStrArray[2]);
        saveWar WarData = JsonUtility.FromJson<saveWar>(saveStrArray[3]);
        saveAng AngData = JsonUtility.FromJson<saveAng>(saveStrArray[4]);

        yield return SRdata;
        yield return Sdata;
        yield return WizData;
        yield return WarData;
        yield return AngData;
        if(!Sdata.isNewIEH)
        {
            main.Log("Sorry, this save is incompatible with this version of Incremental Epic Heroes" );
            yield break;
        }
        main.SR = SRdata;
        main.S = Sdata; 
        main.saveWiz = WizData;
        main.saveWar = WarData;
        main.saveAng = AngData;
        yield return new WaitForSeconds(1.0f);
        SceneManager.LoadScene(sceneName);
    }

    public TextAsset saveFile_Debug;
    [ContextMenu("Editorからロード")]
    void LoadOnEditor()
    {
        if(saveFile_Debug == null)
        {
            Debug.Log("saveFileを儀式してください。");
            return;
        }
        StartCoroutine(LoadOnEditorCor(saveFile_Debug.text));
    }

    IEnumerator LoadOnEditorCor(string data)
    {
        //コルーチンを止める．
         foreach(ACHIEVEMENT achieve in main.quests)
         {
            if(achieve.QuestCor!=null)
                StopCoroutine(achieve.QuestCor);
         }
        //StopAllCoroutines();
        yield return data;
        jsonArray = data.Split('#');
        //復号化
        for (int i = 0; i < jsonArray.Length; i++)
        {
            saveStrArray[i] = null;
            saveStrArray[i] = System.Text.Encoding.UTF8.GetString(aes.dencrypt(Convert.FromBase64String(jsonArray[i])));
            yield return saveStrArray[i];
        }
        SaveR SRdata = JsonUtility.FromJson<SaveR>(saveStrArray[0]);
        Save Sdata = JsonUtility.FromJson<Save>(saveStrArray[1]);
        saveWiz WizData = JsonUtility.FromJson<saveWiz>(saveStrArray[2]);
        saveWar WarData = JsonUtility.FromJson<saveWar>(saveStrArray[3]);
        saveAng AngData = JsonUtility.FromJson<saveAng>(saveStrArray[4]);
        yield return SRdata;
        yield return Sdata;
        yield return WizData;
        yield return WarData;
        yield return AngData;
        if (!Sdata.isNewIEH)
        {
            main.Log("Sorry, this save is incompatible with this version of Incremental Epic Heroes");
            yield break;
        }
        main.SR = SRdata;
        main.S = Sdata;
        main.saveWiz = WizData;
        main.saveWar = WarData;
        main.saveAng = AngData;
        yield return new WaitForSeconds(1.0f);
        SceneManager.LoadScene("main");
    }
}
