﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UniRx.Async;
using System.Windows.Forms;
using System.IO;
using static BASE;

public class LoadTest : MonoBehaviour
{
    UnityEngine.UI.Button loadButton;
    // Start is called before the first frame update
    void Start()
    {
        loadButton = gameObject.GetComponent<UnityEngine.UI.Button>();
        // Local
        loadButton.onClick.AddListener(Load);
    }

    void Load()
    {
        var task = GetUserData();
    }

    public async UniTask<string> GetUserData()
    {
        var fileContent = string.Empty;
        var filePath = string.Empty;

        main.Log("load テスト中です");

        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //Get the path of specified file
                filePath = openFileDialog.FileName;

                //Read the contents of the file into a stream
                var fileStream = openFileDialog.OpenFile();

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                }
            }
        }

        await UniTask.WaitWhile(() => fileContent == string.Empty);
        return fileContent;
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
