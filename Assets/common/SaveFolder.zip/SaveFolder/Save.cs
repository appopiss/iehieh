﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[System.Serializable]
public class Save
{
    public long EpicCoin;
    public bool[] Slot_canEquipped;
    public bool[] SlotG_canEquipped;
    public bool[] isDropped;
    public float CurrentNitro;
    public int[] BankUpgradeLevel;
    public bool isNewIEH;
    public int[] dungeonClearNum;

    //ポーションの数
    public long HpPotion;
    public long MpPotion;
    public long CurePotion;
    public long SpicyPotion;
    public long ExpPotion;
    public long GoldPotion;
    public long DropPotion;
    public long PoisonBanana;
    public int EquipmentBuyNum;

    public double WalkDistance;

    public double SlimeCoin;
    public double TempStoreSlimeCoin;


    //ミッション
    public bool[] M_isCleared;

    public string lastTime;
    public string birthDate;
    public bool isContinuePlay;
    public double allTime;

    public float SEVolume;
    public float BGMVolume;

    public long ascendPoint;
    public bool isAscend;
    public bool isOnAscendConfirm;
    public bool isDead;
    /* libraryここまで */
    /* ここから永久に保存したい変数をpublicで宣言していく */
    /* 初期化はSave */

    //Temrorary Dungeon time
    public string[] dungeonPlayTime;

    //ReleaseContents
    public bool FirstButton;
    public bool isJobbed;

    //解禁
    //public bool[] canEquipped;
    //チュートリアル
    public bool isUpgrade;
    public bool isSkillTreeOpen;
    public bool isSkillTree;
    public bool isSkillSet;
    public bool isDungeonOpen;
    public bool isSlimeHideoutTryAgainFirst;//スライムダンジョンの達成率を最初だけ0%にするためだけのブール
    public bool isSlimeHideoutClear;
    //グローバルスロット
    public bool isGlobalSlotEquipped;
    //ActiveSill
    public bool isWarActiveSkill, isWizActiveSkill, isAngActiveSkill;
    //UPGRADEアイコン
    public bool isUpgradeIcon1;
    public bool isUpgradeIcon2;
    public bool isUpgradeIcon3;
    public bool isUpgradeIcon4;
    public bool isUpgradeIcon5;
    public bool isUpgradeIcon6;
    public bool isUpgradeIcon7;
    public bool isUpgradeIcon8;
    public bool isUpgradeIcon9;
    public bool isUpgradeIcon10;
    public bool isUpgradeIcon11;
    public bool isUpgradeIcon12;
    public bool isUpgradeIcon13;
    public bool isUpgradeIcon14;
    public bool isUpgradeIcon15;
    //DUNGEON
    public bool[] isDungeon;
    //ZONE
    public bool isZone1;
    public bool isZone2;
    public bool isZone3;
    public bool isZone4;
    public bool isZone5;
    public bool isZone6;
    public bool isZone7;

    //最高到達フロア（ランキングやアチーブメントに使う）統計量
    public int maxFloorNum;
    public int maxFloorNum1;
    public int maxFloorNum2;
    public int maxFloorNum3;
    public int maxFloorNum4;
    public int AscendNum;

    public long totalEnemyKilled;
    public long totalSlimeKilled;
    public long[] totalEnemiesKilled;
    public long totalClickNum;
    public double totalGetStone;
    public double totalGetCrystal;
    public double totalGetLeaf;
    //Challenge Boss
    public long C_totalSlimeKilled;
    public long C_totalFairyKilled;
    public long C_totalGolemKilled;
    public long C_totalBananoonKilled;
    public long C_totalDeathpiderKilled;
    public long C_totalMontblangoKilled;
    public long C_totalDistortionSlimeKilled;
    public long C_totalOctoKilled;
    public bool C_S_isDefeatedOnce, C_F_isDefeatedOnce, C_G_isDefeatedOnce, C_M_isDefeatedOnce, C_D_isDefeatedOnce, C_B_isDefeatedOnce, C_Dis_isDefeatedOnce;
    public bool C_O_isDefeatedOnce;


    //SkillLevel
    public ALLY.Job job;
    //Warrior
    public int SLv_wariior;
    public int SLv_slash;
    public int SLv_doubleSlash;
    public int SLv_sonicSlash;
    public int SLv_swingDown;
    public int SLv_swingAround;
    public int SLv_chargeSwing;
    public int SLv_fanSwing;
    public int SLv_shieldAttack;
    public int SLv_block;
    //Wizard
    public int SLv_stuffAttack;
    public int SLv_fireBall;
    public int SLv_fireStorm;
    public int SLv_meteoStrike;
    public int SLv_iceBall;
    public int SLv_chillingTouch;
    public int SLv_blizzard;
    public int SLv_thunderBall;
    public int SLv_doubleThunderBall;
    public int SLv_lightningThunder;
    //Angel
    public int SLv_wingAttack;
    public int SLv_wingShoot;
    public int SLv_heal;
    public int SLv_godBless;
    public int SLv_muscleInflation;
    public int SLv_magicImpact;
    public int SLv_protectWall;
    public int SLv_haste;
    public int SLv_angelDistraction;
    public int SLv_holdWings;

    //SkillProficiency
    //Warrior
    public double SPro_warrior;
    public double SPro_slash;
    public double SPro_doubleSlash;
    public double SPro_sonicSlash;
    public double SPro_swingDown;
    public double SPro_swingAround;
    public double SPro_chargeSwing;
    public double SPro_fanSwing;
    public double SPro_shieldAttack;
    public double SPro_block;
    //Wizard
    public double SPro_stuffAttack;
    public double SPro_fireBall;
    public double SPro_fireStorm;
    public double SPro_meteoStrike;
    public double SPro_iceBall;
    public double SPro_chillingTouch;
    public double SPro_blizzard;
    public double SPro_thunderBall;
    public double SPro_doubleThunderBall;
    public double SPro_lightningThunder;
    //Angel
    public double SPro_wingAttack;
    public double SPro_wingShoot;
    public double SPro_heal;
    public double SPro_godBless;
    public double SPro_muscleInflation;
    public double SPro_magicImpact;
    public double SPro_protectWall;
    public double SPro_haste;
    public double SPro_angelDistraction;
    public double SPro_holdWings;

    //スキル解禁可能条件
    //Warrior
    public bool canS_warrior;
    public bool canS_slash;
    public bool canS_doubleSlash;
    public bool canS_sonicSlash;
    public bool canS_swingDown;
    public bool canS_swingAround;
    public bool canS_chargeSwing;
    public bool canS_fanSwing;
    public bool canS_shieldAttack;
    public bool canS_block;
    //Wizard
    public bool canS_stuffAttack;
    public bool canS_fireBall;
    public bool canS_fireStorm;
    public bool canS_meteoStrike;
    public bool canS_iceBall;
    public bool canS_chillingTouch;
    public bool canS_blizzard;
    public bool canS_thunderBall;
    public bool canS_doubleThunderBall;
    public bool canS_lightningThunder;
    //Angel
    public bool canS_wingAttack;
    public bool canS_wingShoot;
    public bool canS_heal;
    public bool canS_godBless;
    public bool canS_muscleInflation;
    public bool canS_magicImpact;
    public bool canS_protectWall;
    public bool canS_haste;
    public bool canS_angelDistraction;
    public bool canS_holdWings;

    //Challange
    public int clear1, clear2, clear3, clear4, clear5,clear6,clear7,clear8,clear9;
    public int clear_Slime,clear_spider,clear_montblango,clear_distortion,clear_octo;
    public bool iC_fairy, iC_golem, iC_bananoon, iC_slimeBoss,iC_slime,iC_spider,iC_montblango,iC_distortion,iC_octo;
    public int mClear_slime, mClear_fairy, mClear_golem, mClear_bananoon, mClear_spider, mClear_montblango, mClear_distortion, mClear_octo;

    //Artifact 
    public int[] materialNum;
    public int[] consumeItemNum;
    public ARTIFACT.Condition[] condition;
    public MATERIAL.Condition[] condition2;
    public float[] leftTime2;
    public float[] leftTime;
    public int[] storedNum;
    public bool[] isEquipped;
    public int[] level;
    public int[] evolutionNum;
    public float[] duration = new float[20];

    //ConsumeItemFactor
    public double hpPortion;
    public double mpPortion;

    //Achievement
    public bool[] isUnlocked;
    public ACHIEVEMENT.Mode[] mode;
    public int[] clearNum;
    public long QuestPoint;

    //JobChange
    public double WarP, WizP, AngP;
    public int[] A_level = new int[100];

    //System
    public bool dmgTxtLimitOff;
    public bool isDeathPanel;
    public float dmgTxtLimit;
    public float bgmSliderValue = 0.2f;
    public float seSliderValue  = 0.2f;

    //DarkRitual
    public double[] JemLevel;
    public double[] CurrentExp;
    public bool[] isJemUnlocked;

    //ReinCarnation
    public double RP;

    //Quest
    public bool isRainbowFish;
    public int[] Q_upgradeLevel;
    public bool[] isS_treasureHunt;
    public bool[] isS_errand;
    public bool[] isS_merciless;
    public bool[] isS_slimeLover;
    public bool isPurse, isPoppy;
    public long DefeatBySlimeBall;
    public float MT_slime = 99999f, MT_bat = 99999f, MT_fairy = 99999f, MT_spider = 99999f;
    public bool merciless;
}