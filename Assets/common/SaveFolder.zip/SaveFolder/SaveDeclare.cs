﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using static UsefulMethod;
using static UsefulStatic;

/// <summary>
/// 主にsaveしたい配列の初期化を行うクラス
/// InitializeArray(ref main.SR.hoge, サイズ);
/// のようにして初期化する。アップデートなどで途中から変更することも可能。
/// 初期化はAwake()のAwakeBASE();のあとに書くことを推奨。
/// </summary>
public class SaveDeclare : BASE {

	// Use this for initialization/
	void Awake () {
		StartBASE();
        InitializeArray(ref main.SR.currentSkill, 40);
        InitializeArray(ref main.SR.currentGrobalSkill, 40);
        InitializeArray(ref main.S.materialNum, 200);
        InitializeArray(ref main.S.condition, 100);
        InitializeArray(ref main.S.condition2, 100);
        InitializeArray(ref main.S.leftTime2, 100);
        InitializeArray(ref main.S.leftTime, 100);
        InitializeArray(ref main.S.isEquipped, 100);
        InitializeArray(ref main.S.level, 100);
        InitializeArray(ref main.S.isUnlocked, 100);
        InitializeArray(ref main.S.isDungeon, 100);
        InitializeArray(ref main.SR.dungeonPlayTime, 100);
        InitializeArray(ref main.SR.maxDungeonFloorNum, 100);
        InitializeArray(ref main.S.dungeonPlayTime, 100);
        //InitializeArray(ref main.S.canEquipped, 30);

        //InitializeArray(ref main.S.A_level, 100);
        InitializeArray(ref main.SR.R_materials, 200);
        InitializeArray(ref main.SR.RC_materials, 200);
        InitializeArray(ref main.SR.saveSkillId, 40);
        InitializeArray(ref main.SR.saveGrobalSkillId, 40);
        InitializeArray(ref main.S.storedNum, 100);
        InitializeArray(ref main.SR.currentWorkerNum, 20);
        InitializeArray(ref main.S.JemLevel, 20);
        InitializeArray(ref main.S.CurrentExp, 20);
        InitializeArray(ref main.S.isJemUnlocked, 20);

        //Reincarnation
        InitializeArray(ref main.saveWar.canGetExp, 20);
        InitializeArray(ref main.saveWar.SkillLevel, 20);
        InitializeArray(ref main.saveWar.exp, 20);

        InitializeArray(ref main.saveWiz.canGetExp, 20);
        InitializeArray(ref main.saveWiz.SkillLevel, 20);
        InitializeArray(ref main.saveWiz.exp, 20);

        InitializeArray(ref main.saveAng.canGetExp, 20);
        InitializeArray(ref main.saveAng.SkillLevel, 20);
        InitializeArray(ref main.saveAng.exp, 20);
        InitializeArray(ref main.S.mode, 100);
        InitializeArray(ref main.S.clearNum, 100);
        InitializeArray(ref main.S.Q_upgradeLevel, 100);
        InitializeArray(ref main.S.isS_treasureHunt, 10);
        InitializeArray(ref main.S.isS_errand, 10);
        InitializeArray(ref main.S.isS_slimeLover, 10);
        InitializeArray(ref main.S.isS_merciless, 10);
        InitializeArray(ref main.S.evolutionNum, 100);
        InitializeArray(ref main.S.M_isCleared, 100);
        InitializeArray(ref main.S.Slot_canEquipped, 9);
        InitializeArray(ref main.S.SlotG_canEquipped, 20);
        InitializeArray(ref main.S.dungeonClearNum, 100);

        //EnemyDefeatedNum
        InitializeArray(ref main.S.totalEnemiesKilled, Enum.GetNames(typeof(ENEMY.EnemyKind)).Length);


        /* ConsumeItem */
        InitializeArray(ref main.S.consumeItemNum, Enum.GetNames(typeof(ArtiCtrl.ConsumeItemList)).Length);
        InitializeArray(ref main.S.isDropped, Enum.GetNames(typeof(ArtiCtrl.MaterialList)).Length);
        InitializeArray(ref main.S.BankUpgradeLevel, Enum.GetNames(typeof(B_Upgrade.UpgradeId)).Length);
    }

	// Use this for initialization
	void Start () {

	}
}
